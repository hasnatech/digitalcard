<?php
$this->load->view('common/menu');
?>
<div class="space-50"></div>
<div class="container">
    <h1>Privacy</h1>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Deleniti, exercitationem debitis quasi eum repudiandae eius distinctio veritatis rerum deserunt voluptatibus. Corrupti quisquam, voluptates nesciunt laboriosam illum dolores nulla iste architecto.</p>
</div>
<div class="space-50"></div>
<?php
$this->load->view('common/footer-dark');
?>