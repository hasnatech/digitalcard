</div>
<footer class="main-footer">
    <div class="container1">
        <?php $config = get_config(); ?>
        <div class="d-flex">

            <div class="flex-fill">
                <strong>Copyright &copy; <?php echo date('Y'); ?>.</strong> All rights reserved.
                <!-- <?php echo $config['powered']; ?> -->
            </div>
            <div class="hidden-xs">
                <b>Version</b> <?php echo $config['version']; ?>
            </div>
        </div>
    </div>
</footer>
</body>

</html>